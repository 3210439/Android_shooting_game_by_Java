package com.example.framework;

import java.util.HashMap;

import Game.BackGround;
import Game.GameState;
import Game.StartState;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
	private GameViewThread m_thread;
	private IState m_state;
	private GraphicObject m_Image;
	private static Vibrator vibrator;
	private DBHelper m_helper;
	
	// soundManager
	private SoundPool m_SoundPool;
	private HashMap m_SoundPoolMap;
	private AudioManager m_AudioManager;
	private Context m_Activity;
	private MediaPlayer mp;
	
	private boolean retry = false;
	public boolean exit = false;
	public boolean rank = false;
	
	public DBHelper getDBHelper(){
		return m_helper;
	}
	
	public boolean getRetry(){
		return retry;
	}
	public void setRetry(boolean x){
		retry = x;
	}
	
	
	public static Vibrator getVibrator(){
		return vibrator;
	}
	
	public GameView(Context context) {
		super(context);
		// Ű �Է� ó���� �ޱ� ���ؼ�
		setFocusable(true);
		
		m_helper = new DBHelper(context, "rank.db", null, 1);
		AppManager.getInstance().setGameView(this);
		AppManager.getInstance().setResources(getResources());
		getHolder().addCallback(this); // callback ���� ������ ������ �Լ� �ý����� ������ ���ߴ�.
		
		m_thread = new GameViewThread(getHolder(), this);
		
//		SoundManager.getInstance().Init(context);
//		SoundManager.getInstance().addSound(1, R.raw.fire);
		
		m_SoundPool = new SoundPool(4,AudioManager.STREAM_MUSIC, 0);
		m_SoundPoolMap = new HashMap();
		m_AudioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
		m_Activity = context;
		addSound(1,R.raw.shot);
		addSound(2,R.raw.explosion2);
		addSound(3,R.raw.explode_blue);
		
		mp = MediaPlayer.create(context, R.raw.back);
		mp.setLooping(true);
		mp.start();

		
//	
		//m_Image = new GraphicObject(AppManager.getInstance().getBitmap(R.drawable.))
		vibrator = (Vibrator)context.
				getSystemService(Context.VIBRATOR_SERVICE);
		//ChangeGameState(new IntroState());
		//ChangeGameState(new TestState());
		ChangeGameState(new StartState());
		//ChangeGameState(new GameState());
		
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		m_state.onKeyDown(keyCode, event);
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		m_state.onTouchEvent(event);
		return true;
	}
	public void ChangeGameState(IState _state){
		if(m_state != null) m_state.Destroy();
		_state.Init();
		m_state=_state;
	}

	public void Update(){
		m_state.Update();
		if(retry == true){
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BackGround.m_scroll= -2000+480;
			ChangeGameState(new GameState());
			retry = false;
		}
		
		if(exit == true){
			ChangeGameState(new StartState());
			exit = false;
		}
		if(rank == true){
			ChangeGameState(new IntroState());
			rank = false;
		}
			
	}
	
	

	@Override // �ݹ� �Լ��� ���� 3���� �޼ҵ尡 �����Ǿ���.
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		getHolder().setFixedSize(320,480);
		
		DisplayMetrics outMetrics = new DisplayMetrics();
		Context context = this.getContext();  
		((WindowManager)context.getSystemService(Context.WINDOW_SERVICE))
		.getDefaultDisplay().getMetrics(outMetrics);
		
	}



	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		// �����带 ���� ���·� ����ϴ�.
		m_thread.setRunning(true);
		// ������ ����
		m_thread.start();
	}



	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		boolean retry = true;
		m_thread.setRunning(false);
		while(retry){
			try{
				m_thread.join();// ���� ������� ��ĥ �� ��� , ����ó�� �ʼ�
				retry = false;
			}catch(InterruptedException e){
				// �����尡 ����ǵ��� ��� �õ��մϴ�.
			}
		}
	}



	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		Bitmap _scratch = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
		canvas.drawColor(Color.BLACK);
		m_state.Render(canvas);
		//canvas.drawBitmap(_scratch, 10, 10,null); // �θ� �µ�ο쿡 ���� ������ ���� �������� ������ ���� �ɸ���.
	
	}
	
	public void addSound(int _index, int _soundID){
		int id = m_SoundPool.load(m_Activity, _soundID,1); // ���带 �ε�
		m_SoundPoolMap.put(_index, id); // �ؽøʿ� �Ƶ��� ���� �޾ƿ� �ε����� ����
	}
	
	public void play(int _index){
		// ���� ���
		float streamVolume = m_AudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
		streamVolume = streamVolume / m_AudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
		m_SoundPool.play((Integer)m_SoundPoolMap.get(_index), streamVolume, streamVolume, 1, 0, 1f);
	}
	
	public void playLooped(int _index){
		// ���� �ݺ� ���
		float streamVolume = m_AudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
		streamVolume = streamVolume / m_AudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
		m_SoundPool.play((Integer) m_SoundPoolMap.get(_index), streamVolume, streamVolume, 1, -1, 1f);
	}
	

	
	



}
