package com.example.framework;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;

public class IntroState implements IState {
	Bitmap background;
	int x;
	int y;
	
	@Override
	public void Init() {
		background = AppManager.getInstance()
				.getBitmap(R.drawable.startbackground);
	}

	@Override
	public void Destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Update() {
		//long GameTime = System.currentTimeMillis();
	}

	@Override
	public void Render(Canvas canvas) {
		canvas.drawBitmap(background, 0,0,null);
		Paint p = new Paint();
		p.setTextSize(35); p.setColor(Color.YELLOW);
		canvas.drawText("Top10_Score",40,50,p);
		p.setTextSize(30);
		SQLiteDatabase db = AppManager.getInstance().getGameView()
				.getDBHelper().getReadableDatabase();
		
		Cursor cursor = db.query("RankBoard", 
				new String[]{"name","score"},null, null, null, null, "score desc");
		
		
		for(int i=0; i<9; i++){
			if(cursor.moveToNext() == false) break;
			canvas.drawText(i+1 + "st Player : " + cursor.getString(1),
					40, 100+ (30*i),p);
		}
		p.setTextSize(25);
		p.setColor(Color.CYAN);
		canvas.drawText("press to back to menu",40,450,p);
		db.close();
		
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return true;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if(event.getAction() == event.ACTION_DOWN){
			AppManager.getInstance().getGameView().exit = true;
		}
		return true;
	}

}
