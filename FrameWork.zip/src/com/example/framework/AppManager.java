package com.example.framework;

import Game.GameState;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class AppManager { // single ton -> ���Ϲ���
	private static AppManager s_instance;
	private GameView m_gameview;
	private Resources m_resources;
	
	// GameState
	public GameState m_gamestate;
	
	
	public static AppManager getInstance(){
		if(s_instance == null){
			s_instance = new AppManager();
		}
		return s_instance;
	}
	
	void setGameView(GameView _gameview){
		m_gameview = _gameview;
	}
	void setResources(Resources _resources){
		m_resources = _resources;
	}
	public GameView getGameView(){
		return m_gameview;
	}
	public Resources getResources(){
		return m_resources;
	}
	
	public Bitmap getBitmap(int r) {
		return BitmapFactory.decodeResource(m_resources, r);
	}
	
	
	

}
