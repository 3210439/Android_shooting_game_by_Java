package com.example.framework;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.KeyEvent;
import android.view.MotionEvent;

public class TestState implements IState {
	private GraphicObject m_Image;
	private SpriteAnimation m_spr;
	private Bitmap walk; 
	
	@Override
	public void Init() {
		m_Image=new GraphicObject(AppManager.getInstance()
				.getBitmap(R.drawable.android));
		walk = BitmapFactory.decodeResource(AppManager.getInstance().getResources(),R.drawable.walk);
		m_spr = new SpriteAnimation(walk);
		m_spr.InitSpriteData(125, 167, 5, 4); // 1�ʿ� 5�� 4�� ¥��
	}

	@Override
	public void Destroy() {
		
	}

	@Override
	public void Update() {
		long GameTime = System.currentTimeMillis();
		m_spr.Update(GameTime);
	}

	@Override
	public void Render(Canvas canvas) {
		//m_Image.Draw(canvas);
		m_spr.Draw(canvas);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return false;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return false;
	}

}
