package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

import android.graphics.Bitmap;

public class Enemy_2 extends Enemy {

	public Enemy_2() {
		super(AppManager.getInstance().getBitmap
				(R.drawable.enem_22));
		InitSpriteData(58,60,4,6);
		hp = 2;
		speed = 1.5f;
		movetype=Enemy.MOVE_PATTERN_2;
	}

	void Attack(){
		if(System.currentTimeMillis() - LastShoot >= 1000){
			LastShoot = System.currentTimeMillis();
			// �̻����� �߻��ϴ� ����
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x-15, m_y+50));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+15, m_y+50));
		}
	}
	
	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		Move();Attack();
		m_BoundBox.set(m_x,m_y,m_x+58,m_y+60);
	}
	

}
