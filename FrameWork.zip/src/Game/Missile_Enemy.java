package Game;

import com.example.framework.AppManager;


import com.example.framework.R;

import android.graphics.Bitmap;

public class Missile_Enemy extends Missile {

	public Missile_Enemy(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.missile_2));
		this.setPosition(x, y);
		// TODO Auto-generated constructor stub
	}
	
	public void Update(){
		// �̻����� �Ʒ��� �߻�Ǵ� ȿ���� �ش�.
		m_y += 4;
		if(m_y > 350)
			state = STATE_OUT;

			m_BoundBox.set(m_x, m_y, m_x+43, m_y+43);
		
	}

}
