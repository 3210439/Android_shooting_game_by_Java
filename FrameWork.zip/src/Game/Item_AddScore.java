package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

import android.graphics.Bitmap;

public class Item_AddScore extends Item {

	public Item_AddScore(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.coin2));
		InitSpriteData(24,24,4,6);
		m_x=x;
		m_y=y;
	}
	
	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		m_BoundBox.set(m_x,m_y, m_x+24,m_y+24);
	}
	

	@Override
	void getItem() {
		AppManager.getInstance().m_gamestate.m_score+=100;
	}
	
	

}
