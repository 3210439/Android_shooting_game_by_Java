package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

import android.graphics.Bitmap;

public class Item_AddLife extends Item {

	public Item_AddLife(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.heart));
		InitSpriteData(55,46,6,6);
		m_x=x;
		m_y=y;
	}
	
	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		m_BoundBox.set(m_x,m_y, m_x+55,m_y+46);
	}
	

	@Override
	void getItem() {
		AppManager.getInstance().m_gamestate.getPlayer().AddLife();
	}
	
	

}
