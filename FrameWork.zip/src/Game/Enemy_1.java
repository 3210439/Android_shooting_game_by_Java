package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

import android.graphics.Bitmap;

public class Enemy_1 extends Enemy {

	public Enemy_1() {
		super(AppManager.getInstance().getBitmap
				(R.drawable.enem_1_re));
		InitSpriteData(40,40,4,6);
		hp = 1;
		speed = 2f;
		movetype=Enemy.MOVE_PATTERN_2;
	}
	
	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		Move();
		m_BoundBox.set(m_x,m_y,m_x+40,m_y+40);
	}
	

}
