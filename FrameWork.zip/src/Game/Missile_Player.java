package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

public class Missile_Player extends Missile {
	Missile_Player(int x, int y){
		super(AppManager.getInstance().getBitmap(R.drawable.lazer2));
		this.setPosition(x+11, y);
	}
	public void Update(){
		
		m_y -=4;
		if(m_y <0)
			state = STATE_OUT;
		
		m_BoundBox.left = m_x;
		m_BoundBox.top  = m_y;
		m_BoundBox.right= m_x+5;
		m_BoundBox.bottom=m_y+21;
	}
}