package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

import android.graphics.Bitmap;

public class Enemy_4 extends Enemy {

	public Enemy_4() {
		super(AppManager.getInstance().getBitmap
				(R.drawable.boss));
		InitSpriteData(160,154,3,4);
		hp = 150;
		speed = 1f;
		movetype=Enemy.MOVE_PATTERN_4;
	}

	@Override
	void Attack(){
		if(System.currentTimeMillis() - LastShoot >= 1500){
			LastShoot = System.currentTimeMillis();
			// �̻����� �߻��ϴ� ����
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+38, m_y+80));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+38, m_y+60));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+66, m_y+40));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+66, m_y+25));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+18, m_y+80));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+18, m_y+60));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x-6, m_y+40));
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x-6, m_y+25));
			}
	}

	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		Attack();
		Move();
		m_BoundBox.set(m_x,m_y,m_x+160,m_y+154);
	}
	

}
