package Game;

import android.graphics.Rect;

import com.example.framework.AppManager;
import com.example.framework.R;
import com.example.framework.SpriteAnimation;

public class Effect_blue_Explosion extends SpriteAnimation {
	Rect rect;
	public Effect_blue_Explosion(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.explo));
		InitSpriteData(60, 60,9, 6);
		//InitSpriteData(66, 104, 3, 6);
		
		rect = new Rect();
		m_x = x;
		m_y = y;
		rect.set(x, y, x+60, y+60);
		mbReply=false;
	}

}
