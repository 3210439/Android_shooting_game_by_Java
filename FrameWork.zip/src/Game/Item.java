package Game;

import android.graphics.Bitmap;
import android.graphics.Rect;

import com.example.framework.SpriteAnimation;

public class Item extends SpriteAnimation {
	Rect m_BoundBox = new Rect();
	public boolean bOut = false;

	public Item(Bitmap bitmap) {
		super(bitmap);
		
	}

	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		
		m_y+=2;
		if(m_y>350) bOut = true;
	}
	
	void getItem(){
		
	}

}
