package Game;

import android.graphics.Rect;

public class CollisionManager {
	public static boolean CheckBoxToBox(Rect rt1, Rect enem){
		if(rt1.intersect(enem)) return true;
		else return false;
	}
}
