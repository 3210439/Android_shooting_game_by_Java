package Game;

import java.util.Random;

import android.graphics.Bitmap;
import android.graphics.Rect;

import com.example.framework.AppManager;
import com.example.framework.SpriteAnimation;

public class Enemy extends SpriteAnimation {
	protected int hp;
	protected float speed;
	public static final int MOVE_PATTERN_1=0;
	public static final int MOVE_PATTERN_2=1;
	public static final int MOVE_PATTERN_3=2;
	public static final int MOVE_PATTERN_4=3;
	boolean left;
	boolean right;
	int delay_move=0;
	
	protected int movetype;
	
	public int state = Missile.STATE_NORMAL;
	
	Rect m_BoundBox= new Rect();
	
	long LastShoot = System.currentTimeMillis();
	
	public int getHp(){
		return hp;
	}
	
	public Enemy(Bitmap bitmap) {
		super(bitmap);
		// TODO Auto-generated constructor stub
	}
	public void underAttack(int a){
		hp-=a;
	}
	
	void Move(){
		if(movetype==MOVE_PATTERN_1){
			if(m_y <= 200)
				m_y+=speed;
			else{
				m_y+=speed*2;
			}
		}
		else if(movetype==MOVE_PATTERN_2){
			if(m_y <= 200)
				m_y+=speed;
			else{
				m_y+=speed;
				m_x+=speed;
			}
		}
		else if(movetype==MOVE_PATTERN_3){
			if(m_y <= 200)
				m_y+=speed;
			else{
				m_y+=speed;
				m_x-=speed;
			}
		}
		
		else if(movetype==MOVE_PATTERN_4){
			if(delay_move >100000)
			{
				delay_move =0;
			}
			delay_move++;
			if(m_y <= 50)
				m_y+=speed;
			if(right == false && left == false){
				right = true;
			}
			if(right == true){
				if(delay_move%2==0)
					m_x++;
			}
			else if(left == true){
				if(delay_move%2==0)
				m_x--;
			}
			if(m_x< 20){
				right = true;
				left = false;
			}
			if(m_x> 160){
				left = true;
				right = false;
			}
			
		}
		
		if(m_y>350) state = Missile.STATE_OUT;
	}
	
	void Attack(){
		if(System.currentTimeMillis() - LastShoot >= 1500){
			LastShoot = System.currentTimeMillis();
			// �̻����� �߻��ϴ� ����
			AppManager.getInstance().m_gamestate.m_enemmslist.add(new Missile_Enemy(m_x+18, m_y+20));
		}
	}

	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		
	}
	
	

}
