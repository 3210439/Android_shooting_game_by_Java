package Game;

import java.util.ArrayList;
import java.util.Random;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.example.framework.AppManager;
import com.example.framework.GameView;
import com.example.framework.IState;
import com.example.framework.R;

public class GameState implements IState {
	private Player m_player;
	private BackGround m_background;
	
	Random randEnem = new Random();
	
	ArrayList<Enemy> m_enemlist=new ArrayList<Enemy>();
	ArrayList<Missile_Player> m_pmslist=new ArrayList<Missile_Player>();
	ArrayList<Effect_Explosion> m_explist=new ArrayList<Effect_Explosion>();
	ArrayList<Effect_blue_Explosion> m_b_explist=new ArrayList<Effect_blue_Explosion>();
	ArrayList<blue_ms> m_bmslist=new ArrayList<blue_ms>();
	Effect_blue_Explosion ebe;
	ArrayList<Missile> m_enemmslist = new ArrayList<Missile>();
	ArrayList<Item> m_itemlist = new ArrayList<Item>();
	Bitmap m_buttons;
	private int Hp_Item_Regen=0;
	Enemy BOSS;
	
	
	long LastRegenEnemy=System.currentTimeMillis();
	long LastRegenM=System.currentTimeMillis();
	
	Vibrator m_vibrator;
	int a;
	int y_y;
	int touchX;
	int touchY;
	int x;
	int y;
	boolean died = false;
	boolean thereIsABoss = false;
	boolean bossIsDead = false;
	
	private Rect retry_rect;
	private Rect main_rect;
	
	public int m_score=0;
	public String str = "0";
	public int delay=30;
	
	public Player getPlayer(){
		return m_player;
	}
	
	public GameState(){
		AppManager.getInstance().m_gamestate = this; 
		m_vibrator = GameView.getVibrator();
		m_buttons = AppManager.getInstance().getBitmap(R.drawable.buttons);
		retry_rect = new Rect();
		retry_rect.set(36, 453, 175, 493);
		main_rect = new Rect();
		main_rect.set(264, 454, 383, 497);
		
		SQLiteDatabase db = AppManager.getInstance().getGameView()
				.getDBHelper().getReadableDatabase();
		
		Cursor cursor = db.query("RankBoard", 
				new String[]{"name","score"},null, null, null, null, "score desc");
		
		if(cursor.moveToNext() == true) 
		 str = String.valueOf(cursor.getString(1));
		
		db.close();
		
		
	}
	
	public void MakeEnemy(){
		if(System.currentTimeMillis()>=LastRegenEnemy+1000){
			LastRegenEnemy = System.currentTimeMillis();
			Hp_Item_Regen++;
			if(Hp_Item_Regen%10==0){
				m_itemlist.add(new Item_AddLife(randEnem.nextInt(280), -60));
			}
		
			int enemtype=randEnem.nextInt(3);
			Enemy enem=null;
			
			if(enemtype == 0){
				MakeEnemy_2();
//				enem=new Enemy_1();
				return;
			}
			else if(enemtype == 1)
				enem=new Enemy_2();
			else if(enemtype == 2)
				enem=new Enemy_3();

			
			
			enem.setPosition(randEnem.nextInt(260), -60);
			//enem.movetype=Enemy.MOVE_PATTERN_1;
			enem.movetype=randEnem.nextInt(3); // 0~2
			m_enemlist.add(enem);
		}
	}
	
	public void MakeEnemy_2(){
		
		
			Enemy enem1=null;
			Enemy enem2=null;
			Enemy enem3=null;
			enem1=new Enemy_1();
			enem2=new Enemy_1();
			enem3=new Enemy_1();	
			int position = randEnem.nextInt(160);
			int move=randEnem.nextInt(3);
			
			enem1.setPosition(position, -60);
			enem2.setPosition(position+50, -120);
			enem3.setPosition(position+100, -180);
			
			enem1.movetype=move; // 0~2
			enem2.movetype=move; // 0~2
			enem3.movetype=move; // 0~2
			
			m_enemlist.add(enem1);
			m_enemlist.add(enem2);
			m_enemlist.add(enem3);
		
	}
	
	@Override
	public void Init() {
		m_player = new Player(AppManager.getInstance().getBitmap(R.drawable.player_1));
		m_background = new BackGround(0);
	}

	@Override
	public void Destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Update() {
		long GameTime = System.currentTimeMillis();
		m_player.Update(GameTime);
		m_background.Update(GameTime);
		
		
		for(Missile_Player pms:m_pmslist){
			pms.Update();
		}
		
		for(Enemy enem:m_enemlist){
			enem.Update(GameTime);
		}
		if(thereIsABoss == true && bossIsDead == false){
			BOSS.Update(GameTime);
			if(BOSS.getHp() <=0) bossIsDead = true;
			
		}
		
		for (int i=m_pmslist.size()-1; i>=0;i--){
			Missile_Player pms=m_pmslist.get(i);
			pms.Update();
			if(pms.state==Missile.STATE_OUT)
				m_pmslist.remove(i);
		}
		for(int i=m_bmslist.size()-1;i>=0;i--){
			blue_ms bms = m_bmslist.get(i);
			bms.Update(GameTime);
			if(bms.state == blue_ms.STATE_OUT)
				m_bmslist.remove(i);
		}
		for(int i=m_enemmslist.size()-1; i>=0; i--){
			Missile enemms = m_enemmslist.get(i);
			enemms.Update();
			if(enemms.state == Missile.STATE_OUT){
				m_enemmslist.remove(i);
			}
		}
		for (int i=m_enemlist.size()-1; i>=0;i--){
			Enemy enem = m_enemlist.get(i);
			enem.Update(GameTime);
			if(enem.state==Missile.STATE_OUT)
				m_enemlist.remove(i);
		}
		for (int i=m_explist.size()-1; i>=0;i--){
			Effect_Explosion exp = m_explist.get(i);
			exp.Update(GameTime);
			
		}
		for(int i=0; i<m_explist.size()-1; i++){
			if(m_explist.get(i).getAnimation() == true){
				m_explist.remove(i);
			}
		}
		
		for (int i=m_b_explist.size()-1; i>=0;i--){
			Effect_blue_Explosion exp = m_b_explist.get(i);
			
			exp.Update(GameTime);			
			for(int j=0; j<m_enemlist.size(); j++){
				if(exp.rect.contains(m_enemlist.get(j).m_BoundBox)){
					m_enemlist.get(j).underAttack(5);
				}
				if(m_enemlist.get(j).hp <=0){
					m_explist.add(new Effect_Explosion(
							m_enemlist.get(j).getX(),
							m_enemlist.get(j).getY()
							));
					m_itemlist.add(new Item_AddScore(
							m_enemlist.get(j).getX(),
							m_enemlist.get(j).getY()
				
							));
					m_enemlist.remove(j);
					
				}
			}
			
			
		}
		for(int i=0; i<m_b_explist.size()-1; i++){
			if(m_b_explist.get(i).getAnimation() == true){
				m_b_explist.remove(i);
			}
		}
		for(int i=0; i<m_itemlist.size();i++)
		{
			Item item = m_itemlist.get(i);
			item.Update(GameTime);
			
			if(item.bOut == true){
				m_itemlist.remove(i);
			}
		}
		
		
		
		if(LastRegenM +400-delay < System.currentTimeMillis() 
				&& m_player.getLife()>0&& bossIsDead == false)
		{
			LastRegenM = System.currentTimeMillis();
			x = m_player.getX();
			y = m_player.getY();
			a++;
			if(a%10 == 0 && delay >=300){
			 m_bmslist.add(new blue_ms(x+10,y-15));
			}
			
			m_pmslist.add(new Missile_Player(x+10,y-15));
			AppManager.getInstance().getGameView().play(1);
			//SoundManager.getInstance().play(1);
		}
		
		if(BackGround.m_scroll >=-50 && thereIsABoss == false){
			BOSS= new Enemy_4();
			BOSS.setPosition(80, -154);
			BOSS.movetype=3; // 0~2
			m_enemlist.add(BOSS);
			thereIsABoss = true;
			
		}
		MakeEnemy();
		CheckCollision();
	}

	// �׸��� ����
	@Override
	public void Render(Canvas canvas) {
		Paint p = new Paint();
		m_background.Draw(canvas);
		for(Missile_Player pms:m_pmslist){
			pms.Draw(canvas);
		}
		if(m_player.getLife()>0&& bossIsDead == false)
			m_player.Draw(canvas);
		
		for(blue_ms bms:m_bmslist){
			bms.Draw(canvas);
		}
		
		
		for(Missile enemms : m_enemmslist){
			enemms.Draw(canvas);
		}
		for(Enemy enem:m_enemlist){
			enem.Draw(canvas);
		}
		
		for(Effect_Explosion exp:m_explist){
			exp.Draw(canvas);
		}
		for(Effect_blue_Explosion exp:m_b_explist){
			exp.Draw(canvas);
		}
		
		for(Item item:m_itemlist){
			item.Draw(canvas);
		}
		if(thereIsABoss == true && bossIsDead == false){
			BOSS.Draw(canvas);
		}
		
		if(m_player.getLife()==0 || bossIsDead == true){
			canvas.drawBitmap(m_buttons, 12,270, null);
			p.setTextSize(50); p.setColor(Color.YELLOW);
			if(bossIsDead == false)
				canvas.drawText("Game Over",35,200,p);
			else
				canvas.drawText("Game Clear",35,200,p);	
			
			p.setTextSize(20); p.setColor(Color.CYAN);
			canvas.drawText("Score : " + String.valueOf(m_score),50,235,p);
			int n1 = Integer.parseInt(str);
			if(n1>m_score)
				canvas.drawText("Best Score : " + str,50,265,p);
			else
				canvas.drawText("Best Score : " + m_score,50,265,p);
			
			
			
		}
		else{
			p.setTextSize(20); p.setColor(Color.YELLOW);
			canvas.drawText("Life : " + String.valueOf(m_player.getLife()),0,20,p);
			canvas.drawText("Score : " + String.valueOf(m_score),0,41,p);
			canvas.drawText("power level :" + String.valueOf(delay/30),0,62,p);
			
			if(thereIsABoss == true && bossIsDead == false){
				p.setColor(Color.LTGRAY);
				canvas.drawText("Boss HP:" + String.valueOf(BOSS.getHp()),200,20,p);
			}
			
//			canvas.drawText("x :" + String.valueOf(x),0,61,p);
//			canvas.drawText("y :" + String.valueOf(y),0,81,p);
//			canvas.drawText("touchX :" + String.valueOf(touchX),0,101,p);
//			canvas.drawText("touchY :" + String.valueOf(touchY),0,121,p);
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// Ű �Ӥ��¿� ���� �÷��̾� �̵�
		x = m_player.getX();
		y = m_player.getY();
		if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT)
			m_player.setPosition(x-4, y);
		if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
			m_player.setPosition(x+4, y);
		if(keyCode == KeyEvent.KEYCODE_DPAD_UP)
			m_player.setPosition(x, y-4);
		if(keyCode == KeyEvent.KEYCODE_DPAD_DOWN)
			m_player.setPosition(x+4, y+4);
		if(keyCode == KeyEvent.KEYCODE_8)
		{
			SQLiteDatabase db = AppManager.getInstance().getGameView().
					getDBHelper().getWritableDatabase();
			
			ContentValues row = new ContentValues();
			row.put("name", "player");
			row.put("score", m_score);
			db.insert("RankBoard", null, row);
			db.close();
			AppManager.getInstance().getGameView().exit = true;
		}
			
//		if(keyCode == KeyEvent.KEYCODE_SPACE)
//			m_pmslist.add(new Missile_Player(x+10,y-15));
//		
		return true;
			
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		touchX = (int) event.getX();
		touchY = (int) event.getY();
		x = m_player.getX();
		y = m_player.getY();
		
		if(event.getAction() == event.ACTION_DOWN){
			if(m_player.getLife()<=0|| bossIsDead == true){
				
				if(retry_rect.contains(touchX, touchY)){
					AppManager.getInstance().getGameView().setRetry(true);
					SQLiteDatabase db = AppManager.getInstance().getGameView().
							getDBHelper().getWritableDatabase();
					
					ContentValues row = new ContentValues();
					row.put("name", "player");
					row.put("score", m_score);
					db.insert("RankBoard", null, row);
					db.close();
				}
				else if(main_rect.contains(touchX, touchY)){
					SQLiteDatabase db = AppManager.getInstance().getGameView().
							getDBHelper().getWritableDatabase();
					
					ContentValues row = new ContentValues();
					row.put("name", "player");
					row.put("score", m_score);
					db.insert("RankBoard", null, row);
					db.close();
					AppManager.getInstance().getGameView().exit = true;
					
				}
			}
			
		}

		if(m_player.getLife()>0&& bossIsDead == false)
			m_player.setPosition(touchX-100, touchY-touchY/2);

		return true;
	}

	public void CheckCollision(){
		int k=0;
		Random rand = new Random();
		for(Missile_Player pms:m_pmslist){
			k=0;
			for(Enemy enem: m_enemlist){
				
				boolean check = CollisionManager.CheckBoxToBox(pms.m_BoundBox, enem.m_BoundBox);
				if(check){
					
					
					AppManager.getInstance().getGameView().play(2);
					enem.underAttack(1);
					m_pmslist.remove(pms);
					if(enem.hp <=0){

						if(rand.nextInt(10)<8){
							m_itemlist.add(new Item_AddScore(
									m_enemlist.get(k).getX(),
									m_enemlist.get(k).getY()
									));
							}
						else{
							m_itemlist.add(new Item_PowerUp(
									m_enemlist.get(k).getX(),
									m_enemlist.get(k).getY()
									));
							
						}
						
						m_explist.add(new Effect_Explosion(
								m_enemlist.get(k).getX(),
								m_enemlist.get(k).getY()
								));
						m_enemlist.remove(enem);
					}
					return;
				}
				k++;
			}
		}
		
		for(blue_ms bms:m_bmslist){
			k=0;
			for(Enemy enem: m_enemlist){
				
				boolean check = CollisionManager.CheckBoxToBox(bms.rect, enem.m_BoundBox);
				if(check){
					enem.underAttack(5);
					m_bmslist.remove(bms);
					AppManager.getInstance().getGameView().play(3);

					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-80,
							m_enemlist.get(k).getY()
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+80,
							m_enemlist.get(k).getY()
							));

					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-40,
							m_enemlist.get(k).getY()+10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+40,
							m_enemlist.get(k).getY()-10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-60,
							m_enemlist.get(k).getY()+10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+60,
							m_enemlist.get(k).getY()-10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-40,
							m_enemlist.get(k).getY()-10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+40,
							m_enemlist.get(k).getY()+10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-60,
							m_enemlist.get(k).getY()-10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+60,
							m_enemlist.get(k).getY()+10
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-20,
							m_enemlist.get(k).getY()
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+20,
							m_enemlist.get(k).getY()
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX(),
							m_enemlist.get(k).getY()-20
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX(),
							m_enemlist.get(k).getY()+20
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()+20,
							m_enemlist.get(k).getY()+20
							));
					m_b_explist.add(new Effect_blue_Explosion(
							m_enemlist.get(k).getX()-20,
							m_enemlist.get(k).getY()-20
							));
					if(enem.hp <=0){
						m_itemlist.add(new Item_AddScore(
								m_enemlist.get(k).getX(),
								m_enemlist.get(k).getY()
					
								));
						m_enemlist.remove(enem);
					}
					return;
				}
				k++;
			}
		}
		for(int i = m_enemlist.size()-1; i>=0; i--){
			if(CollisionManager.CheckBoxToBox(m_player.m_BoundBox, m_enemlist.get(i).m_BoundBox)){
				m_explist.add(new Effect_Explosion(
						m_enemlist.get(i).getX(),
						m_enemlist.get(i).getY()
						));
				m_vibrator.vibrate(150);
				m_enemlist.remove(i);
				
				m_player.destroyPlayer();
				if(m_player.getLife()<=0){
					m_explist.add(new Effect_Explosion(
							m_player.getX(),
							m_player.getY()
							));
				}
			}
		}
		for(int i = m_enemmslist.size()-1; i>=0; i--){
			if(CollisionManager.CheckBoxToBox(m_player.m_BoundBox, m_enemmslist.get(i).m_BoundBox)){
				m_vibrator.vibrate(150);
				m_enemmslist.remove(i);
				if(m_player.getLife()>0)
					m_player.destroyPlayer();
//				if(m_player.getLife()<=0){
				m_explist.add(new Effect_Explosion(
						m_player.getX(),
						m_player.getY()
						));
			}
			}
		for(int i = m_itemlist.size()-1; i>=0; i--){
				if(CollisionManager.CheckBoxToBox(m_player.m_BoundBox, m_itemlist.get(i).m_BoundBox)){
					m_itemlist.get(i).getItem();		
					m_itemlist.remove(i);
				}
			}
		
	}

}
