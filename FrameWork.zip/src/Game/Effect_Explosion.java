package Game;

import android.graphics.Bitmap;

import com.example.framework.AppManager;
import com.example.framework.R;
import com.example.framework.SpriteAnimation;

public class Effect_Explosion extends SpriteAnimation {

	public Effect_Explosion(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.explosion));
		InitSpriteData(66, 104, 3, 6);
		
		m_x = x;
		m_y = y;
		mbReply=false;
	}

}
