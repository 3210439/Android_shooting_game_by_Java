package Game;

import com.example.framework.AppManager;
import com.example.framework.R;

import android.graphics.Bitmap;

public class Item_PowerUp extends Item {

	public Item_PowerUp(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.powerup));
		InitSpriteData(40,21,4,6);
		m_x=x;
		m_y=y;
	}
	
	@Override
	public void Update(long GameTime) {
		super.Update(GameTime);
		m_BoundBox.set(m_x,m_y, m_x+40,m_y+21);
	}
	

	@Override
	void getItem() {
		if(270>=AppManager.getInstance().m_gamestate.delay)
			AppManager.getInstance().m_gamestate.delay +=30;
		else
			AppManager.getInstance().m_gamestate.m_score+=100;
	}
	
	

}
