package Game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.example.framework.AppManager;
import com.example.framework.IState;
import com.example.framework.R;

public class StartState implements IState {
	Bitmap background;
	Bitmap start_button;
//	Bitmap exit_button;
	Rect start_range;
	Rect ranking_range;
	private int x=0;
	private int y=0;
	
	@Override
	public void Init() {
		background = AppManager.getInstance()
				.getBitmap(R.drawable.startbackground);
		start_button = AppManager.getInstance()
				.getBitmap(R.drawable.start_buttons);
//		exit_button = AppManager.getInstance()
//				.getBitmap(R.drawable.exitbutton);
		
		start_range = new Rect();
		ranking_range = new Rect();
		start_range.set(100, 514, 305, 545);
		ranking_range.set(107, 612, 301, 654);
		
	}

	@Override
	public void Destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Update() {
		long GameTime = System.currentTimeMillis();
	}
	

	@Override
	public void Render(Canvas canvas) {
		canvas.drawBitmap(background, 0,0,null);
		canvas.drawBitmap(start_button, 70,310,null);
		
		Paint p = new Paint();
		p.setTextSize(52); p.setColor(Color.YELLOW);
		canvas.drawText("Space War",33,100,p);
		
//		p.setTextSize(20); p.setColor(Color.YELLOW);
//		canvas.drawText("x :" + String.valueOf(x),0,20,p);
//		canvas.drawText("y :" + String.valueOf(y),0,40,p);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT)
			AppManager.getInstance().getGameView().setRetry(true);
		if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
			AppManager.getInstance().getGameView().rank = true;
		return false;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		x = (int)event.getX();
		y = (int)event.getY();
		if(event.getAction() == event.ACTION_DOWN){
			if(start_range.contains(x, y))
				AppManager.getInstance().getGameView().setRetry(true);
			else if(ranking_range.contains(x, y))
			{
				AppManager.getInstance().getGameView().rank = true;
			}
		}
		return true;
	}

}
