package Game;

import android.graphics.Rect;

import com.example.framework.AppManager;
import com.example.framework.R;
import com.example.framework.SpriteAnimation;

public class blue_ms extends SpriteAnimation {
	
	int state=0;
	public static final int STATE_OUT =1;
	Rect rect;
	public blue_ms(int x, int y) {
		super(AppManager.getInstance().getBitmap(R.drawable.blue_ms));
		InitSpriteData(18,38,3,3);
		this.setPosition(x, y);
		rect = new Rect();
	}
	
	public void Update(long GameTime){
		super.Update(GameTime);
		m_y -=2;
		
		rect.set(m_x, m_y, m_x+18, m_y+38);
		if(m_y < 0)
			state = STATE_OUT;
		
	}

}
